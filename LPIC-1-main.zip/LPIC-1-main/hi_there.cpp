#include <iostream>

using namespace std;

// Just a semple test program that displays text to the screen.
//

int main()
{
	cout << "Hello there!  How are you?" << endl;
	return 0;
}
